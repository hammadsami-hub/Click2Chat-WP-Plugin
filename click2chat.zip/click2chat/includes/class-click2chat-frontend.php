<?php
/**
 * Front-end output: floating button, popup, shortcode.
 *
 * @package Click2Chat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Click2Chat_Frontend
 */
class Click2Chat_Frontend {

	/**
	 * Whether the floating widget should render on this request.
	 *
	 * @var bool
	 */
	private $display = false;

	/**
	 * Whether the inline CSS was already attached.
	 *
	 * @var bool
	 */
	private $css_added = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'wp_footer', array( $this, 'render' ), 20 );
		add_shortcode( 'click2chat', array( $this, 'shortcode' ) );
	}

	/**
	 * Register and (when needed) enqueue assets.
	 */
	public function assets() {
		wp_register_style( 'click2chat', CLICK2CHAT_URL . 'assets/css/frontend.css', array(), CLICK2CHAT_VERSION );
		wp_register_script(
			'click2chat',
			CLICK2CHAT_URL . 'assets/js/frontend.js',
			array(),
			CLICK2CHAT_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		$this->display = $this->should_display();

		if ( $this->display ) {
			$this->enqueue_style();
			wp_enqueue_script( 'click2chat' );
		}
	}

	/**
	 * Enqueue the stylesheet plus the generated settings CSS (once).
	 */
	private function enqueue_style() {
		wp_enqueue_style( 'click2chat' );
		if ( ! $this->css_added ) {
			$this->css_added = true;
			wp_add_inline_style( 'click2chat', self::build_css( Click2Chat_Settings::get() ) );
		}
	}

	/**
	 * Decide whether the floating button is shown on the current request.
	 *
	 * @return bool
	 */
	private function should_display() {
		$s = Click2Chat_Settings::get();

		if ( empty( $s['enabled'] ) || '' === $s['number'] || is_admin() || is_feed() || is_embed() ) {
			return false;
		}

		// Keep the Elementor editor canvas clean.
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->preview ) && \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
			return false;
		}

		if ( ! empty( $s['hide_logged_in'] ) && is_user_logged_in() ) {
			return false;
		}

		if ( is_front_page() || is_home() ) {
			$show = ! empty( $s['show_front'] );
		} elseif ( is_singular( 'post' ) ) {
			$show = ! empty( $s['show_posts'] );
		} elseif ( is_singular( 'page' ) ) {
			$show = ! empty( $s['show_pages'] );
		} else {
			$show = ! empty( $s['show_other'] );
		}

		if ( $show && '' !== $s['exclude_ids'] ) {
			$excluded = array_map( 'absint', explode( ',', $s['exclude_ids'] ) );
			$current  = (int) get_queried_object_id();
			if ( $current && in_array( $current, $excluded, true ) ) {
				$show = false;
			}
		}

		/**
		 * Filter whether the Click2Chat floating button is displayed.
		 *
		 * @param bool  $show     Whether to display.
		 * @param array $settings Plugin settings.
		 */
		return (bool) apply_filters( 'click2chat_should_display', $show, $s );
	}

	/**
	 * Replace the {page_title}, {page_url} and {site_name} placeholders.
	 *
	 * @param string $message Message template.
	 * @return string
	 */
	public static function parse_message( $message ) {
		global $wp;

		$request = ( isset( $wp ) && is_object( $wp ) && isset( $wp->request ) ) ? $wp->request : '';

		$replace = array(
			'{page_title}' => wp_strip_all_tags( wp_get_document_title() ),
			'{page_url}'   => esc_url_raw( home_url( add_query_arg( array(), $request ) ) ),
			'{site_name}'  => wp_strip_all_tags( get_bloginfo( 'name' ) ),
		);

		return trim( strtr( (string) $message, $replace ) );
	}

	/**
	 * Build the wa.me chat URL.
	 *
	 * @param array       $s       Settings.
	 * @param string|null $message Optional message override.
	 * @param string|null $number  Optional number override (digits).
	 * @return string
	 */
	public static function chat_url( $s, $message = null, $number = null ) {
		$number = ( null !== $number ) ? preg_replace( '/\D+/', '', (string) $number ) : $s['number'];
		$text   = self::parse_message( ( null !== $message ) ? $message : $s['prefill'] );
		$url    = 'https://wa.me/' . $number;

		if ( '' !== $text ) {
			$url .= '?text=' . rawurlencode( $text );
		}
		return $url;
	}

	/**
	 * Whether a visible text label is shown for a given device.
	 *
	 * @param array $s      Settings.
	 * @param array $device Device settings.
	 * @return bool
	 */
	public static function has_label( $s, $device ) {
		return Click2Chat_Settings::design_has_text( $s['design'] ) && ! empty( $device['label'] ) && '' !== trim( $s['button_text'] );
	}

	/**
	 * CSS custom properties for one device.
	 *
	 * @param array  $s   Settings.
	 * @param string $dev Device key.
	 * @return array
	 */
	public static function device_vars( $s, $dev ) {
		$d    = $s['devices'][ $dev ];
		$size = (int) $d['size'];
		$ox   = (int) $d['ox'] . 'px';
		$oy   = (int) $d['oy'] . 'px';
		$tx   = '0';
		$ty   = '0';
		$has  = self::has_label( $s, $d );

		$vars = array(
			'--c2c-display'       => ! empty( $d['visible'] ) ? 'block' : 'none',
			'--c2c-size'          => $size . 'px',
			'--c2c-icon'          => round( $size * 0.5 ) . 'px',
			'--c2c-pad'           => $has ? round( $size * 0.4 ) . 'px' : '0px',
			'--c2c-label-display' => $has ? 'inline' : 'none',
			'--c2c-left'          => 'auto',
			'--c2c-right'         => 'auto',
			'--c2c-top'           => 'auto',
			'--c2c-bottom'        => 'auto',
		);

		if ( 'left' === $d['h'] ) {
			$vars['--c2c-left'] = $ox;
		} elseif ( 'right' === $d['h'] ) {
			$vars['--c2c-right'] = $ox;
		} else {
			$vars['--c2c-left'] = '50%';
			$tx                 = '-50%';
		}

		if ( 'top' === $d['v'] ) {
			$vars['--c2c-top'] = $oy;
		} elseif ( 'bottom' === $d['v'] ) {
			$vars['--c2c-bottom'] = $oy;
		} else {
			$vars['--c2c-top'] = '50%';
			$ty                = '-50%';
		}

		$vars['--c2c-transform'] = ( '0' === $tx && '0' === $ty ) ? 'none' : 'translate(' . $tx . ',' . $ty . ')';

		// Popup placement relative to the button.
		if ( 'top' === $d['v'] ) {
			$vars['--c2c-pop-top']    = 'calc(100% + 12px)';
			$vars['--c2c-pop-bottom'] = 'auto';
		} else {
			$vars['--c2c-pop-top']    = 'auto';
			$vars['--c2c-pop-bottom'] = 'calc(100% + 12px)';
		}

		if ( 'left' === $d['h'] ) {
			$vars['--c2c-pop-left']      = '0';
			$vars['--c2c-pop-right']     = 'auto';
			$vars['--c2c-pop-transform'] = 'none';
		} elseif ( 'right' === $d['h'] ) {
			$vars['--c2c-pop-left']      = 'auto';
			$vars['--c2c-pop-right']     = '0';
			$vars['--c2c-pop-transform'] = 'none';
		} else {
			$vars['--c2c-pop-left']      = '50%';
			$vars['--c2c-pop-right']     = 'auto';
			$vars['--c2c-pop-transform'] = 'translateX(-50%)';
		}

		return $vars;
	}

	/**
	 * Turn a variable map into CSS declarations (values are whitelisted).
	 *
	 * @param array $vars Variables.
	 * @return string
	 */
	private static function declarations( $vars ) {
		$css = '';
		foreach ( $vars as $name => $value ) {
			$value = preg_replace( '/[^a-zA-Z0-9#%.,()+\-\s]/', '', (string) $value );
			$css  .= $name . ':' . $value . ';';
		}
		return $css;
	}

	/**
	 * Generate the settings-driven CSS.
	 *
	 * @param array $s Settings.
	 * @return string
	 */
	public static function build_css( $s ) {
		$global = array(
			'--c2c-bg'     => $s['button_bg'],
			'--c2c-color'  => $s['button_color'],
			'--c2c-hover'  => $s['hover_bg'],
			'--c2c-accent' => $s['accent'],
			'--c2c-font'   => (int) $s['font_size'] . 'px',
			'--c2c-shadow' => ! empty( $s['shadow'] ) ? '0 6px 18px rgba(0,0,0,.28)' : 'none',
			'--c2c-z'      => (int) $s['z_index'],
			'--c2c-delay'  => (int) $s['delay'] . 's',
		);

		/**
		 * Filter the responsive breakpoints (max-width, in px).
		 *
		 * @param array $breakpoints Array with 'mobile' and 'tablet' keys.
		 */
		$bp     = apply_filters(
			'click2chat_breakpoints',
			array(
				'mobile' => 767,
				'tablet' => 1024,
			)
		);
		$mobile = max( 1, (int) $bp['mobile'] );
		$tablet = max( $mobile + 1, (int) $bp['tablet'] );

		$css  = '.c2c-widget,.c2c-inline{' . self::declarations( $global ) . '}';
		$css .= '.c2c-widget{' . self::declarations( self::device_vars( $s, 'desktop' ) ) . '}';
		$css .= '@media (max-width:' . $tablet . 'px){.c2c-widget{' . self::declarations( self::device_vars( $s, 'tablet' ) ) . '}}';
		$css .= '@media (max-width:' . $mobile . 'px){.c2c-widget{' . self::declarations( self::device_vars( $s, 'mobile' ) ) . '}}';

		if ( '' !== trim( $s['custom_css'] ) ) {
			$css .= wp_strip_all_tags( $s['custom_css'] );
		}

		return $css;
	}

	/**
	 * Print the icon markup (SVG or custom image).
	 *
	 * @param array $s Settings.
	 */
	private static function print_icon( $s ) {
		if ( 'custom' === $s['icon'] && '' !== $s['custom_icon'] ) {
			echo '<img src="' . esc_url( $s['custom_icon'] ) . '" alt="" width="64" height="64" loading="lazy" decoding="async">';
			return;
		}
		// Static, plugin-defined SVG markup (no user input).
		echo Click2Chat_Settings::icon_svg( $s['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Render the floating widget.
	 */
	public function render() {
		if ( ! $this->display ) {
			return;
		}

		$s       = Click2Chat_Settings::get();
		$url     = self::chat_url( $s );
		$popup   = ! empty( $s['popup_enabled'] );
		$classes = array( 'c2c-widget', 'c2c-design-' . (int) $s['design'] );

		if ( ! empty( $s['animation_enabled'] ) ) {
			$classes[] = 'c2c-anim-' . sanitize_html_class( $s['animation'] );
		}
		if ( ! empty( $s['hover_effect'] ) ) {
			$classes[] = 'c2c-hover-fx';
		}
		if ( ! empty( $s['animation_enabled'] ) || (int) $s['delay'] > 0 ) {
			$classes[] = 'c2c-enter';
		}
		?>
		<div id="click2chat" class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" data-autoopen="<?php echo esc_attr( ( $popup && (int) $s['popup_auto_open'] > 0 ) ? (int) $s['popup_auto_open'] + (int) $s['delay'] : 0 ); ?>">
			<?php if ( $popup ) : ?>
			<div class="c2c-popup" id="click2chat-popup" role="dialog" aria-labelledby="click2chat-popup-title" hidden>
				<div class="c2c-popup-head">
					<span class="c2c-avatar" aria-hidden="true"><?php self::print_icon( $s ); ?></span>
					<span class="c2c-popup-meta">
						<strong id="click2chat-popup-title"><?php echo esc_html( $s['popup_title'] ); ?></strong>
						<span><?php echo esc_html( $s['popup_subtitle'] ); ?></span>
					</span>
					<button type="button" class="c2c-close" aria-label="<?php esc_attr_e( 'Close chat', 'click2chat' ); ?>">
						<?php echo Click2Chat_Settings::icon_svg( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</button>
				</div>
				<div class="c2c-popup-body">
					<?php if ( '' !== trim( $s['welcome_message'] ) ) : ?>
					<div class="c2c-bubble"><?php echo esc_html( $s['welcome_message'] ); ?></div>
					<?php endif; ?>
				</div>
				<div class="c2c-popup-foot">
					<a class="c2c-start" href="<?php echo esc_url( $url ); ?>"<?php echo $s['new_tab'] ? ' target="_blank" rel="noopener noreferrer"' : ''; ?>>
						<span class="c2c-icon" aria-hidden="true"><?php echo Click2Chat_Settings::icon_svg( 'whatsapp' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<span><?php echo esc_html( $s['popup_button'] ); ?></span>
					</a>
				</div>
			</div>
			<?php endif; ?>
			<a class="c2c-btn" href="<?php echo esc_url( $url ); ?>"<?php echo $s['new_tab'] ? ' target="_blank" rel="noopener noreferrer"' : ''; ?><?php echo $popup ? ' role="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="click2chat-popup"' : ''; ?>>
				<span class="c2c-icon" aria-hidden="true"><?php self::print_icon( $s ); ?></span>
				<span class="c2c-label" aria-hidden="true"><?php echo esc_html( $s['button_text'] ); ?></span>
				<span class="c2c-sr"><?php echo esc_html( $s['aria_label'] ); ?></span>
			</a>
		</div>
		<?php
	}

	/**
	 * Shortcode: [click2chat text="Chat now" message="Hi!" number="15551234567"]
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public function shortcode( $atts ) {
		$s    = Click2Chat_Settings::get();
		$atts = shortcode_atts(
			array(
				'text'    => $s['button_text'],
				'message' => $s['prefill'],
				'number'  => $s['number'],
				'class'   => '',
			),
			$atts,
			'click2chat'
		);

		$number = preg_replace( '/\D+/', '', (string) $atts['number'] );
		if ( '' === $number ) {
			return '';
		}

		$this->enqueue_style();

		$url   = self::chat_url( $s, sanitize_textarea_field( $atts['message'] ), $number );
		$class = 'c2c-inline';
		if ( '' !== $atts['class'] ) {
			$class .= ' ' . implode( ' ', array_map( 'sanitize_html_class', explode( ' ', $atts['class'] ) ) );
		}

		ob_start();
		?>
		<a class="<?php echo esc_attr( trim( $class ) ); ?>" href="<?php echo esc_url( $url ); ?>"<?php echo $s['new_tab'] ? ' target="_blank" rel="noopener noreferrer"' : ''; ?>>
			<span class="c2c-icon" aria-hidden="true"><?php self::print_icon( $s ); ?></span>
			<span><?php echo esc_html( sanitize_text_field( $atts['text'] ) ); ?></span>
		</a>
		<?php
		return ob_get_clean();
	}
}
