<?php
/**
 * Settings: defaults, validation, sanitization and shared helpers.
 *
 * @package Click2Chat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Click2Chat_Settings
 */
final class Click2Chat_Settings {

	const OPTION = 'click2chat_settings';

	/**
	 * Request-level cache.
	 *
	 * @var array|null
	 */
	private static $cache = null;

	/**
	 * Whether the invalid-number warning was already queued this request.
	 *
	 * @var bool
	 */
	private static $warned = false;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'update_option_' . self::OPTION, array( __CLASS__, 'flush' ) );
		add_action( 'add_option_' . self::OPTION, array( __CLASS__, 'flush' ) );
	}

	/**
	 * Clear the cached settings.
	 */
	public static function flush() {
		self::$cache = null;
	}

	/**
	 * Available button designs.
	 *
	 * @return array
	 */
	public static function designs() {
		return array(
			1 => __( 'Classic Circle', 'click2chat' ),
			2 => __( 'Pill with Text', 'click2chat' ),
			3 => __( 'Rounded Square', 'click2chat' ),
			4 => __( 'Outline Pill', 'click2chat' ),
			5 => __( 'Gradient Glow', 'click2chat' ),
		);
	}

	/**
	 * Designs that can display a text label.
	 *
	 * @param int $design Design number.
	 * @return bool
	 */
	public static function design_has_text( $design ) {
		return in_array( (int) $design, array( 2, 4, 5 ), true );
	}

	/**
	 * Available icons.
	 *
	 * @return array
	 */
	public static function icons() {
		return array(
			'whatsapp' => __( 'WhatsApp', 'click2chat' ),
			'chat'     => __( 'Chat bubble', 'click2chat' ),
			'sms'      => __( 'Message', 'click2chat' ),
			'headset'  => __( 'Support', 'click2chat' ),
			'send'     => __( 'Paper plane', 'click2chat' ),
			'custom'   => __( 'Custom image', 'click2chat' ),
		);
	}

	/**
	 * SVG path data (24x24 viewBox) for the built-in icons.
	 *
	 * @return array
	 */
	private static function icon_paths() {
		return array(
			'whatsapp' => 'M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z',
			'chat'     => 'M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z',
			'sms'      => 'M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM9 11H7V9h2v2zm4 0h-2V9h2v2zm4 0h-2V9h2v2z',
			'headset'  => 'M12 1C7.03 1 3 5.03 3 10v7c0 1.66 1.34 3 3 3h3v-8H5v-2c0-3.87 3.13-7 7-7s7 3.13 7 7v2h-4v8h4v1h-7v2h6c1.66 0 3-1.34 3-3V10c0-4.97-4.03-9-9-9z',
			'send'     => 'M2.01 21L23 12 2.01 3 2 10l15 2-15 2z',
			'close'    => 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
		);
	}

	/**
	 * Inline SVG markup for an icon. Output is static, plugin-defined markup.
	 *
	 * @param string $key Icon key.
	 * @return string
	 */
	public static function icon_svg( $key ) {
		$paths = self::icon_paths();
		if ( ! isset( $paths[ $key ] ) ) {
			$key = 'whatsapp';
		}
		return '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><path d="' . $paths[ $key ] . '"/></svg>';
	}

	/**
	 * All icons as markup, used by the admin live preview.
	 *
	 * @return array
	 */
	public static function icon_markup_map() {
		$map = array();
		foreach ( array_keys( self::icon_paths() ) as $key ) {
			$map[ $key ] = self::icon_svg( $key );
		}
		return $map;
	}

	/**
	 * Attention animations.
	 *
	 * @return array
	 */
	public static function animations() {
		return array(
			'pulse'  => __( 'Pulse ring', 'click2chat' ),
			'bounce' => __( 'Bounce', 'click2chat' ),
			'shake'  => __( 'Shake', 'click2chat' ),
			'float'  => __( 'Float', 'click2chat' ),
		);
	}

	/**
	 * Device labels.
	 *
	 * @return array
	 */
	public static function devices() {
		return array(
			'desktop' => __( 'Desktop', 'click2chat' ),
			'tablet'  => __( 'Tablet', 'click2chat' ),
			'mobile'  => __( 'Mobile', 'click2chat' ),
		);
	}

	/**
	 * Default settings.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled'           => 1,
			'number'            => '',
			'button_text'       => __( 'Chat with us', 'click2chat' ),
			'aria_label'        => __( 'Chat on WhatsApp', 'click2chat' ),
			'prefill'           => __( 'Hello! I would like to know more.', 'click2chat' ),
			'new_tab'           => 1,

			'popup_enabled'     => 1,
			'popup_title'       => __( 'Support Team', 'click2chat' ),
			'popup_subtitle'    => __( 'Typically replies within minutes', 'click2chat' ),
			'welcome_message'   => __( 'Hi there! 👋 How can we help you today?', 'click2chat' ),
			'popup_button'      => __( 'Start chat', 'click2chat' ),
			'popup_auto_open'   => 0,

			'design'            => 1,
			'icon'              => 'whatsapp',
			'custom_icon'       => '',
			'button_bg'         => '#0E806F',
			'button_color'      => '#FFFFFF',
			'hover_bg'          => '#075E54',
			'accent'            => '#0A4F7A',
			'font_size'         => 15,
			'shadow'            => 1,
			'animation_enabled' => 1,
			'animation'         => 'pulse',
			'hover_effect'      => 1,

			'show_front'        => 1,
			'show_posts'        => 1,
			'show_pages'        => 1,
			'show_other'        => 1,
			'exclude_ids'       => '',
			'hide_logged_in'    => 0,
			'delay'             => 0,
			'z_index'           => 99990,
			'custom_css'        => '',

			'devices'           => array(
				'desktop' => array(
					'visible' => 1,
					'h'       => 'right',
					'v'       => 'bottom',
					'size'    => 60,
					'ox'      => 24,
					'oy'      => 24,
					'label'   => 1,
				),
				'tablet'  => array(
					'visible' => 1,
					'h'       => 'right',
					'v'       => 'bottom',
					'size'    => 56,
					'ox'      => 20,
					'oy'      => 20,
					'label'   => 1,
				),
				'mobile'  => array(
					'visible' => 1,
					'h'       => 'right',
					'v'       => 'bottom',
					'size'    => 52,
					'ox'      => 16,
					'oy'      => 16,
					'label'   => 0,
				),
			),
		);
	}

	/**
	 * Get the saved settings merged over the defaults.
	 *
	 * @return array
	 */
	public static function get() {
		if ( null === self::$cache ) {
			$saved    = get_option( self::OPTION, array() );
			$saved    = is_array( $saved ) ? $saved : array();
			$defaults = self::defaults();
			$merged   = array_merge( $defaults, $saved );

			$devices = array();
			foreach ( $defaults['devices'] as $key => $device_defaults ) {
				$device_saved   = ( isset( $saved['devices'][ $key ] ) && is_array( $saved['devices'][ $key ] ) ) ? $saved['devices'][ $key ] : array();
				$devices[ $key ] = array_merge( $device_defaults, $device_saved );
			}
			$merged['devices'] = $devices;

			self::$cache = $merged;
		}
		return self::$cache;
	}

	/**
	 * Sanitize and validate all settings. Used as the register_setting callback.
	 *
	 * @param mixed $input Raw submitted settings.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$d   = self::defaults();
		$in  = is_array( $input ) ? $input : array();
		$out = array();

		// General.
		$out['enabled'] = self::flag( $in, 'enabled' );

		$number = isset( $in['number'] ) ? preg_replace( '/\D+/', '', (string) $in['number'] ) : '';
		$number = ltrim( (string) $number, '0' );
		$number = substr( $number, 0, 20 );
		if ( '' !== $number && ( strlen( $number ) < 7 || strlen( $number ) > 15 ) && ! self::$warned ) {
			self::$warned = true;
			add_settings_error(
				self::OPTION,
				'click2chat_number',
				__( 'The WhatsApp number looks invalid. Use the full international number with country code (7–15 digits), without + or leading zeros.', 'click2chat' ),
				'warning'
			);
		}
		$out['number'] = $number;

		$out['button_text'] = self::text( $in, 'button_text', $d['button_text'], 40, true );
		$out['aria_label']  = self::text( $in, 'aria_label', $d['aria_label'], 80, false );
		$out['prefill']     = self::textarea( $in, 'prefill', $d['prefill'], 500 );
		$out['new_tab']     = self::flag( $in, 'new_tab' );

		// Popup.
		$out['popup_enabled']   = self::flag( $in, 'popup_enabled' );
		$out['popup_title']     = self::text( $in, 'popup_title', $d['popup_title'], 60, true );
		$out['popup_subtitle']  = self::text( $in, 'popup_subtitle', $d['popup_subtitle'], 80, true );
		$out['welcome_message'] = self::textarea( $in, 'welcome_message', $d['welcome_message'], 500 );
		$out['popup_button']    = self::text( $in, 'popup_button', $d['popup_button'], 40, false );
		$out['popup_auto_open'] = self::int( $in, 'popup_auto_open', 0, 120, 0 );

		// Design.
		$design         = self::int( $in, 'design', 1, 5, 1 );
		$out['design']  = $design;
		$out['icon']    = self::enum( $in, 'icon', array_keys( self::icons() ), $d['icon'] );
		$custom_icon    = isset( $in['custom_icon'] ) ? esc_url_raw( trim( (string) $in['custom_icon'] ), array( 'http', 'https' ) ) : '';
		$out['custom_icon'] = $custom_icon;
		if ( 'custom' === $out['icon'] && '' === $custom_icon ) {
			$out['icon'] = 'whatsapp';
		}
		$out['button_bg']    = self::color( $in, 'button_bg', $d['button_bg'] );
		$out['button_color'] = self::color( $in, 'button_color', $d['button_color'] );
		$out['hover_bg']     = self::color( $in, 'hover_bg', $d['hover_bg'] );
		$out['accent']       = self::color( $in, 'accent', $d['accent'] );
		$out['font_size']    = self::int( $in, 'font_size', 12, 24, $d['font_size'] );
		$out['shadow']       = self::flag( $in, 'shadow' );

		$out['animation_enabled'] = self::flag( $in, 'animation_enabled' );
		$out['animation']         = self::enum( $in, 'animation', array_keys( self::animations() ), $d['animation'] );
		$out['hover_effect']      = self::flag( $in, 'hover_effect' );

		// Display rules.
		$out['show_front']     = self::flag( $in, 'show_front' );
		$out['show_posts']     = self::flag( $in, 'show_posts' );
		$out['show_pages']     = self::flag( $in, 'show_pages' );
		$out['show_other']     = self::flag( $in, 'show_other' );
		$out['hide_logged_in'] = self::flag( $in, 'hide_logged_in' );
		$out['delay']          = self::int( $in, 'delay', 0, 60, 0 );
		$out['z_index']        = self::int( $in, 'z_index', 1, 2147483000, $d['z_index'] );

		$ids = array();
		if ( isset( $in['exclude_ids'] ) ) {
			foreach ( explode( ',', (string) $in['exclude_ids'] ) as $id ) {
				$id = absint( trim( $id ) );
				if ( $id > 0 ) {
					$ids[] = $id;
				}
			}
		}
		$out['exclude_ids'] = implode( ',', array_unique( $ids ) );
		$out['custom_css']  = isset( $in['custom_css'] ) ? substr( wp_strip_all_tags( (string) $in['custom_css'] ), 0, 5000 ) : '';

		// Per-device settings.
		$out['devices'] = array();
		foreach ( $d['devices'] as $key => $dd ) {
			$di = ( isset( $in['devices'][ $key ] ) && is_array( $in['devices'][ $key ] ) ) ? $in['devices'][ $key ] : null;
			if ( null === $di ) {
				$out['devices'][ $key ] = $dd;
				continue;
			}
			$out['devices'][ $key ] = array(
				'visible' => self::flag( $di, 'visible' ),
				'h'       => self::enum( $di, 'h', array( 'left', 'center', 'right' ), $dd['h'] ),
				'v'       => self::enum( $di, 'v', array( 'top', 'middle', 'bottom' ), $dd['v'] ),
				'size'    => self::int( $di, 'size', 36, 120, $dd['size'] ),
				'ox'      => self::int( $di, 'ox', 0, 300, $dd['ox'] ),
				'oy'      => self::int( $di, 'oy', 0, 600, $dd['oy'] ),
				'label'   => self::flag( $di, 'label' ),
			);
		}

		return $out;
	}

	/**
	 * Checkbox helper.
	 *
	 * @param array  $in  Input.
	 * @param string $key Key.
	 * @return int
	 */
	private static function flag( $in, $key ) {
		return empty( $in[ $key ] ) ? 0 : 1;
	}

	/**
	 * Integer helper with clamping.
	 *
	 * @param array  $in      Input.
	 * @param string $key     Key.
	 * @param int    $min     Minimum.
	 * @param int    $max     Maximum.
	 * @param int    $default Default.
	 * @return int
	 */
	private static function int( $in, $key, $min, $max, $default ) {
		if ( ! isset( $in[ $key ] ) || ! is_numeric( $in[ $key ] ) ) {
			return (int) $default;
		}
		return max( $min, min( $max, (int) $in[ $key ] ) );
	}

	/**
	 * Whitelist helper.
	 *
	 * @param array  $in      Input.
	 * @param string $key     Key.
	 * @param array  $allowed Allowed values.
	 * @param mixed  $default Default.
	 * @return mixed
	 */
	private static function enum( $in, $key, $allowed, $default ) {
		$value = isset( $in[ $key ] ) ? (string) $in[ $key ] : '';
		return in_array( $value, array_map( 'strval', $allowed ), true ) ? $value : $default;
	}

	/**
	 * Hex colour helper.
	 *
	 * @param array  $in      Input.
	 * @param string $key     Key.
	 * @param string $default Default.
	 * @return string
	 */
	private static function color( $in, $key, $default ) {
		$value = isset( $in[ $key ] ) ? sanitize_hex_color( trim( (string) $in[ $key ] ) ) : '';
		return $value ? $value : $default;
	}

	/**
	 * Single-line text helper.
	 *
	 * @param array  $in          Input.
	 * @param string $key         Key.
	 * @param string $default     Default.
	 * @param int    $max         Max length.
	 * @param bool   $allow_empty Whether an empty value is allowed.
	 * @return string
	 */
	private static function text( $in, $key, $default, $max, $allow_empty ) {
		if ( ! isset( $in[ $key ] ) ) {
			return $default;
		}
		$value = self::truncate( sanitize_text_field( (string) $in[ $key ] ), $max );
		if ( '' === $value && ! $allow_empty ) {
			return $default;
		}
		return $value;
	}

	/**
	 * Multi-line text helper.
	 *
	 * @param array  $in      Input.
	 * @param string $key     Key.
	 * @param string $default Default.
	 * @param int    $max     Max length.
	 * @return string
	 */
	private static function textarea( $in, $key, $default, $max ) {
		if ( ! isset( $in[ $key ] ) ) {
			return $default;
		}
		return self::truncate( sanitize_textarea_field( (string) $in[ $key ] ), $max );
	}

	/**
	 * Multibyte-safe truncation.
	 *
	 * @param string $value Value.
	 * @param int    $max   Max characters.
	 * @return string
	 */
	private static function truncate( $value, $max ) {
		if ( function_exists( 'mb_substr' ) ) {
			return mb_substr( $value, 0, $max );
		}
		return substr( $value, 0, $max );
	}
}
