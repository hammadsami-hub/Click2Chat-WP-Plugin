<?php
/**
 * Admin dashboard: tabbed settings page with live preview.
 *
 * @package Click2Chat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Click2Chat_Admin
 */
class Click2Chat_Admin {

	const SLUG  = 'click2chat';
	const GROUP = 'click2chat_group';

	/**
	 * Current settings (for the page render).
	 *
	 * @var array
	 */
	private $s = array();

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( CLICK2CHAT_FILE ), array( $this, 'action_links' ) );
	}

	/**
	 * Register the settings.
	 */
	public function register() {
		register_setting(
			self::GROUP,
			Click2Chat_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'Click2Chat_Settings', 'sanitize' ),
				'default'           => Click2Chat_Settings::defaults(),
			)
		);
	}

	/**
	 * Admin menu.
	 */
	public function menu() {
		add_menu_page(
			__( 'Click2Chat', 'click2chat' ),
			__( 'Click2Chat', 'click2chat' ),
			'manage_options',
			self::SLUG,
			array( $this, 'page' ),
			'dashicons-format-chat',
			58
		);
	}

	/**
	 * "Settings" link on the Plugins screen.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function action_links( $links ) {
		$url = admin_url( 'admin.php?page=' . self::SLUG );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'click2chat' ) . '</a>' );
		return $links;
	}

	/**
	 * Enqueue admin assets on our page only.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function assets( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'click2chat-frontend', CLICK2CHAT_URL . 'assets/css/frontend.css', array(), CLICK2CHAT_VERSION );
		wp_enqueue_style( 'click2chat-admin', CLICK2CHAT_URL . 'assets/css/admin.css', array( 'click2chat-frontend' ), CLICK2CHAT_VERSION );
		wp_enqueue_script( 'click2chat-admin', CLICK2CHAT_URL . 'assets/js/admin.js', array( 'jquery', 'wp-color-picker' ), CLICK2CHAT_VERSION, true );
		wp_localize_script(
			'click2chat-admin',
			'click2chatAdmin',
			array(
				'option' => Click2Chat_Settings::OPTION,
				'icons'  => Click2Chat_Settings::icon_markup_map(),
				'i18n'   => array(
					'hidden'      => __( 'The button is hidden on this device.', 'click2chat' ),
					'noNumber'    => __( 'Add your WhatsApp number in the General tab to activate the button.', 'click2chat' ),
					'mediaTitle'  => __( 'Choose a button icon', 'click2chat' ),
					'mediaButton' => __( 'Use this image', 'click2chat' ),
					'showPopup'   => __( 'Show welcome popup', 'click2chat' ),
					'hidePopup'   => __( 'Hide welcome popup', 'click2chat' ),
				),
			)
		);
	}

	/* ------------------------------------------------------------------
	 * Field helpers (each prints one table row).
	 * ---------------------------------------------------------------- */

	/**
	 * Name attribute for a top-level setting.
	 *
	 * @param string $key Key.
	 * @return string
	 */
	private function n( $key ) {
		return Click2Chat_Settings::OPTION . '[' . $key . ']';
	}

	/**
	 * Name attribute for a per-device setting.
	 *
	 * @param string $dev Device.
	 * @param string $key Key.
	 * @return string
	 */
	private function dn( $dev, $key ) {
		return Click2Chat_Settings::OPTION . '[devices][' . $dev . '][' . $key . ']';
	}

	/**
	 * Print a field description.
	 *
	 * @param string $desc Description.
	 */
	private function desc( $desc ) {
		if ( '' !== $desc ) {
			echo '<p class="description">' . esc_html( $desc ) . '</p>';
		}
	}

	/**
	 * Text / number / url input row.
	 *
	 * @param string $label Label.
	 * @param string $name  Name attribute.
	 * @param string $id    ID attribute.
	 * @param mixed  $value Value.
	 * @param string $desc  Description.
	 * @param array  $args  Extra attributes.
	 */
	private function field_input( $label, $name, $id, $value, $desc = '', $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'type'        => 'text',
				'class'       => 'regular-text',
				'placeholder' => '',
				'min'         => '',
				'max'         => '',
				'suffix'      => '',
			)
		);
		?>
		<tr>
			<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label></th>
			<td>
				<input type="<?php echo esc_attr( $args['type'] ); ?>" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" class="<?php echo esc_attr( $args['class'] ); ?>"
					<?php echo '' !== $args['placeholder'] ? 'placeholder="' . esc_attr( $args['placeholder'] ) . '"' : ''; ?>
					<?php echo '' !== $args['min'] ? 'min="' . esc_attr( $args['min'] ) . '"' : ''; ?>
					<?php echo '' !== $args['max'] ? 'max="' . esc_attr( $args['max'] ) . '"' : ''; ?>>
				<?php echo '' !== $args['suffix'] ? '<span class="c2c-suffix">' . esc_html( $args['suffix'] ) . '</span>' : ''; ?>
				<?php $this->desc( $desc ); ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Textarea row.
	 *
	 * @param string $label Label.
	 * @param string $name  Name.
	 * @param string $id    ID.
	 * @param string $value Value.
	 * @param string $desc  Description.
	 * @param int    $rows  Rows.
	 */
	private function field_textarea( $label, $name, $id, $value, $desc = '', $rows = 3 ) {
		?>
		<tr>
			<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label></th>
			<td>
				<textarea id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" rows="<?php echo (int) $rows; ?>" class="large-text"><?php echo esc_textarea( $value ); ?></textarea>
				<?php $this->desc( $desc ); ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Checkbox row.
	 *
	 * @param string $label   Label.
	 * @param string $name    Name.
	 * @param string $id      ID.
	 * @param mixed  $checked Checked state.
	 * @param string $text    Text next to the checkbox.
	 * @param string $desc    Description.
	 */
	private function field_check( $label, $name, $id, $checked, $text, $desc = '' ) {
		?>
		<tr>
			<th scope="row"><?php echo esc_html( $label ); ?></th>
			<td>
				<label for="<?php echo esc_attr( $id ); ?>">
					<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( ! empty( $checked ) ); ?>>
					<?php echo esc_html( $text ); ?>
				</label>
				<?php $this->desc( $desc ); ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Select row.
	 *
	 * @param string $label   Label.
	 * @param string $name    Name.
	 * @param string $id      ID.
	 * @param string $value   Current value.
	 * @param array  $options value => label.
	 * @param string $desc    Description.
	 */
	private function field_select( $label, $name, $id, $value, $options, $desc = '' ) {
		?>
		<tr>
			<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label></th>
			<td>
				<select id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>">
					<?php foreach ( $options as $opt_value => $opt_label ) : ?>
						<option value="<?php echo esc_attr( $opt_value ); ?>" <?php selected( (string) $value, (string) $opt_value ); ?>><?php echo esc_html( $opt_label ); ?></option>
					<?php endforeach; ?>
				</select>
				<?php $this->desc( $desc ); ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Colour picker row.
	 *
	 * @param string $label Label.
	 * @param string $key   Setting key.
	 * @param string $desc  Description.
	 */
	private function field_color( $label, $key, $desc = '' ) {
		$id = 'c2c_' . $key;
		?>
		<tr>
			<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label></th>
			<td>
				<input type="text" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $this->n( $key ) ); ?>" value="<?php echo esc_attr( $this->s[ $key ] ); ?>" class="c2c-color" data-default-color="<?php echo esc_attr( Click2Chat_Settings::defaults()[ $key ] ); ?>">
				<?php $this->desc( $desc ); ?>
			</td>
		</tr>
		<?php
	}

	/* ------------------------------------------------------------------
	 * Page.
	 * ---------------------------------------------------------------- */

	/**
	 * Render the settings page.
	 */
	public function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$this->s = Click2Chat_Settings::get();
		$tabs    = array(
			'general' => __( 'General', 'click2chat' ),
			'design'  => __( 'Design', 'click2chat' ),
			'layout'  => __( 'Position & Responsive', 'click2chat' ),
			'display' => __( 'Display Rules', 'click2chat' ),
			'help'    => __( 'Help & About', 'click2chat' ),
		);
		?>
		<div class="wrap c2c-admin">
			<h1 class="wp-heading-inline">
				<span class="dashicons dashicons-format-chat" aria-hidden="true"></span>
				<?php esc_html_e( 'Click2Chat', 'click2chat' ); ?>
				<span class="c2c-version">v<?php echo esc_html( CLICK2CHAT_VERSION ); ?></span>
			</h1>
			<hr class="wp-header-end">
			<?php settings_errors(); ?>

			<form method="post" action="options.php" id="c2c-form">
				<?php settings_fields( self::GROUP ); ?>

				<div class="c2c-layout">
					<div class="c2c-main">
						<div class="c2c-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Click2Chat settings sections', 'click2chat' ); ?>">
							<?php foreach ( $tabs as $slug => $label ) : ?>
								<button type="button" class="c2c-tab" role="tab" id="c2c-tab-<?php echo esc_attr( $slug ); ?>" data-tab="<?php echo esc_attr( $slug ); ?>" aria-controls="c2c-panel-<?php echo esc_attr( $slug ); ?>" aria-selected="false" tabindex="-1"><?php echo esc_html( $label ); ?></button>
							<?php endforeach; ?>
						</div>

						<div class="c2c-panel" role="tabpanel" id="c2c-panel-general" aria-labelledby="c2c-tab-general" hidden>
							<?php $this->tab_general(); ?>
						</div>
						<div class="c2c-panel" role="tabpanel" id="c2c-panel-design" aria-labelledby="c2c-tab-design" hidden>
							<?php $this->tab_design(); ?>
						</div>
						<div class="c2c-panel" role="tabpanel" id="c2c-panel-layout" aria-labelledby="c2c-tab-layout" hidden>
							<?php $this->tab_layout(); ?>
						</div>
						<div class="c2c-panel" role="tabpanel" id="c2c-panel-display" aria-labelledby="c2c-tab-display" hidden>
							<?php $this->tab_display(); ?>
						</div>
						<div class="c2c-panel" role="tabpanel" id="c2c-panel-help" aria-labelledby="c2c-tab-help" hidden>
							<?php $this->tab_help(); ?>
						</div>

						<?php submit_button( __( 'Save Changes', 'click2chat' ) ); ?>
					</div>

					<aside class="c2c-side" aria-label="<?php esc_attr_e( 'Live preview', 'click2chat' ); ?>">
						<div class="c2c-card c2c-preview-card">
							<h2><?php esc_html_e( 'Live preview', 'click2chat' ); ?></h2>
							<div class="c2c-preview-bar">
								<div class="c2c-devices" role="group" aria-label="<?php esc_attr_e( 'Preview device', 'click2chat' ); ?>">
									<?php foreach ( Click2Chat_Settings::devices() as $key => $label ) : ?>
										<button type="button" class="button c2c-device" data-device="<?php echo esc_attr( $key ); ?>" aria-pressed="<?php echo 'desktop' === $key ? 'true' : 'false'; ?>"><?php echo esc_html( $label ); ?></button>
									<?php endforeach; ?>
								</div>
								<button type="button" class="button c2c-toggle-popup" id="c2c-toggle-popup"><?php esc_html_e( 'Show welcome popup', 'click2chat' ); ?></button>
							</div>
							<div class="c2c-frame" id="c2c-frame">
								<div class="c2c-screen" id="c2c-screen" aria-hidden="true">
									<div class="c2c-fake-nav"></div>
									<div class="c2c-fake-hero"></div>
									<div class="c2c-fake-line"></div>
									<div class="c2c-fake-line short"></div>
									<div class="c2c-fake-cols"><span></span><span></span><span></span></div>
									<div class="c2c-fake-line"></div>
									<div class="c2c-fake-line short"></div>
									<div class="c2c-widget c2c-is-preview" id="c2c-preview-widget"></div>
								</div>
							</div>
							<p class="c2c-preview-note" id="c2c-preview-note" role="status"></p>
						</div>
					</aside>
				</div>
			</form>
		</div>
		<?php
	}

	/**
	 * General tab.
	 */
	private function tab_general() {
		$s = $this->s;
		?>
		<div class="c2c-card">
			<h2><?php esc_html_e( 'Chat settings', 'click2chat' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$this->field_check( __( 'Status', 'click2chat' ), $this->n( 'enabled' ), 'c2c_enabled', $s['enabled'], __( 'Show the WhatsApp button on my site', 'click2chat' ) );
				$this->field_input(
					__( 'WhatsApp number', 'click2chat' ),
					$this->n( 'number' ),
					'c2c_number',
					$s['number'],
					__( 'Full international number including country code, digits only (no +, spaces or leading zeros). Example: 14155550123', 'click2chat' ),
					array(
						'type'        => 'text',
						'placeholder' => '14155550123',
					)
				);
				$this->field_input( __( 'Button text', 'click2chat' ), $this->n( 'button_text' ), 'c2c_button_text', $s['button_text'], __( 'Shown beside the icon in the text-capable designs (2, 4 and 5). Leave empty for an icon-only button.', 'click2chat' ) );
				$this->field_input( __( 'Accessible label', 'click2chat' ), $this->n( 'aria_label' ), 'c2c_aria_label', $s['aria_label'], __( 'Read aloud by screen readers. Describes what the button does.', 'click2chat' ) );
				$this->field_textarea(
					__( 'Pre-filled chat message', 'click2chat' ),
					$this->n( 'prefill' ),
					'c2c_prefill',
					$s['prefill'],
					__( 'The message that is already typed when WhatsApp opens. Placeholders: {page_title}, {page_url}, {site_name}.', 'click2chat' )
				);
				$this->field_check( __( 'Link behaviour', 'click2chat' ), $this->n( 'new_tab' ), 'c2c_new_tab', $s['new_tab'], __( 'Open WhatsApp in a new tab', 'click2chat' ) );
				?>
			</table>
		</div>

		<div class="c2c-card">
			<h2><?php esc_html_e( 'Welcome popup', 'click2chat' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$this->field_check( __( 'Popup', 'click2chat' ), $this->n( 'popup_enabled' ), 'c2c_popup_enabled', $s['popup_enabled'], __( 'Show a welcome card when the button is clicked', 'click2chat' ), __( 'When disabled, the button opens WhatsApp directly.', 'click2chat' ) );
				$this->field_input( __( 'Agent / team name', 'click2chat' ), $this->n( 'popup_title' ), 'c2c_popup_title', $s['popup_title'] );
				$this->field_input( __( 'Subtitle', 'click2chat' ), $this->n( 'popup_subtitle' ), 'c2c_popup_subtitle', $s['popup_subtitle'] );
				$this->field_textarea( __( 'Welcome message', 'click2chat' ), $this->n( 'welcome_message' ), 'c2c_welcome_message', $s['welcome_message'], __( 'Displayed as a chat bubble inside the popup.', 'click2chat' ) );
				$this->field_input( __( 'Start chat button text', 'click2chat' ), $this->n( 'popup_button' ), 'c2c_popup_button', $s['popup_button'] );
				$this->field_input(
					__( 'Auto-open after', 'click2chat' ),
					$this->n( 'popup_auto_open' ),
					'c2c_popup_auto_open',
					$s['popup_auto_open'],
					__( 'Open the popup automatically once per visit after this many seconds. Use 0 to disable.', 'click2chat' ),
					array(
						'type'   => 'number',
						'class'  => 'small-text',
						'min'    => 0,
						'max'    => 120,
						'suffix' => __( 'seconds', 'click2chat' ),
					)
				);
				?>
			</table>
		</div>
		<?php
	}

	/**
	 * Design tab.
	 */
	private function tab_design() {
		$s = $this->s;
		?>
		<div class="c2c-card">
			<h2><?php esc_html_e( 'Button design', 'click2chat' ); ?></h2>
			<fieldset class="c2c-choices c2c-designs">
				<legend class="screen-reader-text"><?php esc_html_e( 'Choose a design', 'click2chat' ); ?></legend>
				<?php foreach ( Click2Chat_Settings::designs() as $num => $label ) : ?>
					<label class="c2c-choice">
						<input type="radio" name="<?php echo esc_attr( $this->n( 'design' ) ); ?>" value="<?php echo esc_attr( $num ); ?>" <?php checked( (int) $s['design'], (int) $num ); ?>>
						<span class="c2c-choice-box">
							<span class="c2c-mini-host" data-design="<?php echo esc_attr( $num ); ?>"></span>
							<span class="c2c-choice-label"><?php echo esc_html( $label ); ?></span>
						</span>
					</label>
				<?php endforeach; ?>
			</fieldset>
		</div>

		<div class="c2c-card">
			<h2><?php esc_html_e( 'Icon', 'click2chat' ); ?></h2>
			<fieldset class="c2c-choices c2c-icons">
				<legend class="screen-reader-text"><?php esc_html_e( 'Choose an icon', 'click2chat' ); ?></legend>
				<?php foreach ( Click2Chat_Settings::icons() as $key => $label ) : ?>
					<label class="c2c-choice">
						<input type="radio" name="<?php echo esc_attr( $this->n( 'icon' ) ); ?>" value="<?php echo esc_attr( $key ); ?>" <?php checked( $s['icon'], $key ); ?>>
						<span class="c2c-choice-box">
							<span class="c2c-icon-sample" aria-hidden="true">
								<?php
								if ( 'custom' === $key ) {
									echo '<span class="dashicons dashicons-format-image"></span>';
								} else {
									echo Click2Chat_Settings::icon_svg( $key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								}
								?>
							</span>
							<span class="c2c-choice-label"><?php echo esc_html( $label ); ?></span>
						</span>
					</label>
				<?php endforeach; ?>
			</fieldset>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="c2c_custom_icon"><?php esc_html_e( 'Custom icon image', 'click2chat' ); ?></label></th>
					<td>
						<input type="url" id="c2c_custom_icon" name="<?php echo esc_attr( $this->n( 'custom_icon' ) ); ?>" value="<?php echo esc_attr( $s['custom_icon'] ); ?>" class="regular-text" placeholder="https://">
						<button type="button" class="button" id="c2c-upload"><?php esc_html_e( 'Choose image', 'click2chat' ); ?></button>
						<button type="button" class="button-link button-link-delete" id="c2c-remove-icon"><?php esc_html_e( 'Remove', 'click2chat' ); ?></button>
						<p class="description"><?php esc_html_e( 'Upload a square PNG/SVG, then select “Custom image” above. Recommended: 64×64 px or larger.', 'click2chat' ); ?></p>
					</td>
				</tr>
			</table>
		</div>

		<div class="c2c-card">
			<h2><?php esc_html_e( 'Colors & appearance', 'click2chat' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$this->field_color( __( 'Button color', 'click2chat' ), 'button_bg' );
				$this->field_color( __( 'Icon & text color', 'click2chat' ), 'button_color', __( 'Use a strong contrast with the button color for readability.', 'click2chat' ) );
				$this->field_color( __( 'Hover color', 'click2chat' ), 'hover_bg' );
				$this->field_color( __( 'Accent color', 'click2chat' ), 'accent', __( 'Second gradient color used by the “Gradient Glow” design.', 'click2chat' ) );
				$this->field_input(
					__( 'Text size', 'click2chat' ),
					$this->n( 'font_size' ),
					'c2c_font_size',
					$s['font_size'],
					'',
					array(
						'type'   => 'number',
						'class'  => 'small-text',
						'min'    => 12,
						'max'    => 24,
						'suffix' => 'px',
					)
				);
				$this->field_check( __( 'Shadow', 'click2chat' ), $this->n( 'shadow' ), 'c2c_shadow', $s['shadow'], __( 'Add a soft drop shadow', 'click2chat' ) );
				?>
			</table>
		</div>

		<div class="c2c-card">
			<h2><?php esc_html_e( 'Animation', 'click2chat' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$this->field_check( __( 'Attention animation', 'click2chat' ), $this->n( 'animation_enabled' ), 'c2c_animation_enabled', $s['animation_enabled'], __( 'Enable animations (they are automatically disabled for visitors who prefer reduced motion)', 'click2chat' ) );
				$this->field_select( __( 'Animation style', 'click2chat' ), $this->n( 'animation' ), 'c2c_animation', $s['animation'], Click2Chat_Settings::animations() );
				$this->field_check( __( 'Hover effect', 'click2chat' ), $this->n( 'hover_effect' ), 'c2c_hover_effect', $s['hover_effect'], __( 'Slightly enlarge the button on hover', 'click2chat' ) );
				?>
			</table>
		</div>
		<?php
	}

	/**
	 * Position & responsive tab.
	 */
	private function tab_layout() {
		$s = $this->s;

		$horizontal = array(
			'left'   => __( 'Left', 'click2chat' ),
			'center' => __( 'Center', 'click2chat' ),
			'right'  => __( 'Right', 'click2chat' ),
		);
		$vertical   = array(
			'top'    => __( 'Top', 'click2chat' ),
			'middle' => __( 'Middle', 'click2chat' ),
			'bottom' => __( 'Bottom', 'click2chat' ),
		);
		?>
		<p class="c2c-intro">
			<?php esc_html_e( 'Each device has its own settings. Desktop applies above 1024px, tablet from 768px to 1024px and mobile up to 767px.', 'click2chat' ); ?>
		</p>
		<?php foreach ( Click2Chat_Settings::devices() as $dev => $dev_label ) : ?>
			<?php $d = $s['devices'][ $dev ]; ?>
			<div class="c2c-card">
				<h2><?php echo esc_html( $dev_label ); ?></h2>
				<table class="form-table" role="presentation">
					<?php
					$this->field_check( __( 'Visibility', 'click2chat' ), $this->dn( $dev, 'visible' ), 'c2c_' . $dev . '_visible', $d['visible'], __( 'Show the button on this device', 'click2chat' ) );
					$this->field_select( __( 'Horizontal position', 'click2chat' ), $this->dn( $dev, 'h' ), 'c2c_' . $dev . '_h', $d['h'], $horizontal );
					$this->field_select( __( 'Vertical position', 'click2chat' ), $this->dn( $dev, 'v' ), 'c2c_' . $dev . '_v', $d['v'], $vertical );
					$this->field_input(
						__( 'Button size', 'click2chat' ),
						$this->dn( $dev, 'size' ),
						'c2c_' . $dev . '_size',
						$d['size'],
						'',
						array(
							'type'   => 'number',
							'class'  => 'small-text',
							'min'    => 36,
							'max'    => 120,
							'suffix' => 'px',
						)
					);
					$this->field_input(
						__( 'Horizontal offset', 'click2chat' ),
						$this->dn( $dev, 'ox' ),
						'c2c_' . $dev . '_ox',
						$d['ox'],
						__( 'Distance from the left or right screen edge (ignored when centered).', 'click2chat' ),
						array(
							'type'   => 'number',
							'class'  => 'small-text',
							'min'    => 0,
							'max'    => 300,
							'suffix' => 'px',
						)
					);
					$this->field_input(
						__( 'Vertical offset', 'click2chat' ),
						$this->dn( $dev, 'oy' ),
						'c2c_' . $dev . '_oy',
						$d['oy'],
						__( 'Distance from the top or bottom screen edge (ignored when in the middle).', 'click2chat' ),
						array(
							'type'   => 'number',
							'class'  => 'small-text',
							'min'    => 0,
							'max'    => 600,
							'suffix' => 'px',
						)
					);
					$this->field_check( __( 'Text label', 'click2chat' ), $this->dn( $dev, 'label' ), 'c2c_' . $dev . '_label', $d['label'], __( 'Show the button text (text-capable designs only)', 'click2chat' ) );
					?>
				</table>
			</div>
		<?php endforeach; ?>
		<?php
	}

	/**
	 * Display rules tab.
	 */
	private function tab_display() {
		$s = $this->s;
		?>
		<div class="c2c-card">
			<h2><?php esc_html_e( 'Where to show the button', 'click2chat' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$this->field_check( __( 'Home page', 'click2chat' ), $this->n( 'show_front' ), 'c2c_show_front', $s['show_front'], __( 'Front page and blog index', 'click2chat' ) );
				$this->field_check( __( 'Posts', 'click2chat' ), $this->n( 'show_posts' ), 'c2c_show_posts', $s['show_posts'], __( 'Single blog posts', 'click2chat' ) );
				$this->field_check( __( 'Pages', 'click2chat' ), $this->n( 'show_pages' ), 'c2c_show_pages', $s['show_pages'], __( 'Static pages (including Elementor pages)', 'click2chat' ) );
				$this->field_check( __( 'Everything else', 'click2chat' ), $this->n( 'show_other' ), 'c2c_show_other', $s['show_other'], __( 'Archives, search, 404, products and other custom post types', 'click2chat' ) );
				$this->field_input(
					__( 'Hide on these IDs', 'click2chat' ),
					$this->n( 'exclude_ids' ),
					'c2c_exclude_ids',
					$s['exclude_ids'],
					__( 'Comma-separated post/page IDs where the button must never appear. Example: 12, 48, 305', 'click2chat' )
				);
				$this->field_check( __( 'Logged-in users', 'click2chat' ), $this->n( 'hide_logged_in' ), 'c2c_hide_logged_in', $s['hide_logged_in'], __( 'Hide the button for logged-in users', 'click2chat' ), __( 'With full-page caching this only works if logged-in users bypass the cache (the default for most caching plugins).', 'click2chat' ) );
				?>
			</table>
		</div>

		<div class="c2c-card">
			<h2><?php esc_html_e( 'Advanced', 'click2chat' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$this->field_input(
					__( 'Appear after', 'click2chat' ),
					$this->n( 'delay' ),
					'c2c_delay',
					$s['delay'],
					__( 'Delay before the button fades in. Use 0 for immediately.', 'click2chat' ),
					array(
						'type'   => 'number',
						'class'  => 'small-text',
						'min'    => 0,
						'max'    => 60,
						'suffix' => __( 'seconds', 'click2chat' ),
					)
				);
				$this->field_input(
					__( 'Z-index', 'click2chat' ),
					$this->n( 'z_index' ),
					'c2c_z_index',
					$s['z_index'],
					__( 'Raise this if another element covers the button.', 'click2chat' ),
					array(
						'type'  => 'number',
						'class' => 'small-text',
						'min'   => 1,
					)
				);
				$this->field_textarea( __( 'Custom CSS', 'click2chat' ), $this->n( 'custom_css' ), 'c2c_custom_css', $s['custom_css'], __( 'Optional. Loaded only on pages where Click2Chat is active.', 'click2chat' ), 6 );
				?>
			</table>
		</div>
		<?php
	}

	/**
	 * Help & about tab.
	 */
	private function tab_help() {
		?>
		<div class="c2c-card">
			<h2><?php esc_html_e( 'Quick start', 'click2chat' ); ?></h2>
			<ol class="c2c-steps">
				<li><?php esc_html_e( 'Enter your WhatsApp number in the General tab (country code first, digits only).', 'click2chat' ); ?></li>
				<li><?php esc_html_e( 'Pick a design, icon and colors in the Design tab and watch the live preview update.', 'click2chat' ); ?></li>
				<li><?php esc_html_e( 'Fine-tune the position and size for desktop, tablet and mobile.', 'click2chat' ); ?></li>
				<li><?php esc_html_e( 'Click Save Changes. Open your website and test the button.', 'click2chat' ); ?></li>
			</ol>
		</div>

		<div class="c2c-card">
			<h2><?php esc_html_e( 'Shortcode', 'click2chat' ); ?></h2>
			<p><?php esc_html_e( 'Place an inline WhatsApp button anywhere — posts, widgets, or the Elementor Shortcode widget:', 'click2chat' ); ?></p>
			<p><code>[click2chat]</code></p>
			<p><code>[click2chat text="Ask us on WhatsApp" message="Hi, I need help with {page_title}"]</code></p>
			<p class="description"><?php esc_html_e( 'Optional attributes: text, message, number, class.', 'click2chat' ); ?></p>
		</div>

		<div class="c2c-card">
			<h2><?php esc_html_e( 'About', 'click2chat' ); ?></h2>
			<p>
				<?php
				printf(
					/* translators: 1: plugin name, 2: author link. */
					esc_html__( '%1$s was created by %2$s.', 'click2chat' ),
					'<strong>Click2Chat</strong>',
					'<a href="' . esc_url( 'https://hammadsami.com' ) . '" target="_blank" rel="noopener noreferrer">Hammad Sami</a>'
				);
				?>
			</p>
			<p class="description"><?php esc_html_e( 'Click2Chat is free software released under the GNU General Public License v2 or later. It is not affiliated with or endorsed by WhatsApp or Meta. Chats open through the official wa.me link only when a visitor clicks the button.', 'click2chat' ); ?></p>
		</div>
		<?php
	}
}
